const swaggerUi         = require("swagger-ui-express");
const swaggerDocument   = require("./swagger.json");

//importing express package to implement web service
const express           = require("express");
const app = express();

//port on which our service will start/run
const port              = 8000;

//importing routes for preferences
const preferenceRoutes = require("./routes/preferenceRoutes");

//any url having /preference will route to preference routes
app.use("/preference", preferenceRoutes);

//swagger URL
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

/*app.get('/', (req, res) => {
    res.send('Hellow World 1');
});*/

app.listen(port, () => {
    console.log(`listining on port ${port}`);
});