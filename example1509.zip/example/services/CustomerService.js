const request = require("request");
const URL = 'https://maciejtreder.github.io/asynchronous-javascript/directors';//dummy URL

//We need Customer Profile URL?
//Sample Request to call customer profile service?
//Sample Response to read customer profile data?

const getCustomerProfile = (paperPreferenceReq, updateAccountsPreferenceCB) => {
	//We need logic to extract user-name from token, pass user-name to below service

	//Header options
	let options = { json: true };

	//call to middle ware customer profile service
	request.get(URL, options, (err, resp, body) => {
		let customerProfile = resp.body;
		console.log('Customer Profile Response :' + JSON.stringify(customerProfile));
		updateAccountsPreferenceCB(paperPreferenceReq, customerProfile);
	});
};

module.exports = { getCustomerProfile};