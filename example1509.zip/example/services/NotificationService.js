const request = require("request");
const EMAIL_SERVICE_URL = 'https://maciejtreder.github.io/asynchronous-javascript/directors';//dummy URL

//We need Notification service URL?
//Sample Request to call service?
//Sample Response data?


const sendEmailNotification = (emailIds, subject, message, notificationServiceCB) => {
	let options = { json: true };

	request.get(EMAIL_SERVICE_URL, options, (err, resp, body) => {
		console.log('Email Notification Response :' + resp.body);
		notificationServiceCB('success','Email Sent Successfully');
	});
};

module.exports.sendEmailNotification = sendEmailNotification;