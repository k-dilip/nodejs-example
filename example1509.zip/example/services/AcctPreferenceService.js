const notificationService = require("../services/NotificationService");

const updateAccountsPreference = (paperPreferenceReq, customerProfile) => {
    
    //Iterate through paper preferences array

    //Call middle ware Save preference service?
    //How to save preferences, is there any API call or Data Base call?
    //If API call :
    //What is the URL, Request and Response

    //If DB call :
    //DB URL, DB Type
    //username
    //password


    //in call back, call notifyCustomer service

    let emailIds = "abc@gmail.com";
    let subject = "Account Preferences changed";
    let message = "Hello Customer, your account preferences successfuly updated.";

    notificationService.sendEmailNotification(emailIds, subject, message, notificationServiceCB);
};

const notificationServiceCB = (status, message) => {
    console.log(status +':'+ message)
}

module.exports.updateAccountsPreference = updateAccountsPreference;

