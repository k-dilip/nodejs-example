const bodyParser            = require("body-parser");
const express               = require("express");

const customerService       = require("../services/CustomerService")
const acctPreferenceService = require("../services/AcctPreferenceService")

let router = express.Router();

router.use(bodyParser.json());

router.route('/saveAndNotify')
    .post((req, res) => {
        //extracting json message from request
        let paperPreferenceReq = req.body.paperPreferenceArray;

        //loggin request
        console.log('Input Request : ' + JSON.stringify(paperPreferenceReq));

        //we need customer details (emailId) for further operations
        customerService.getCustomerProfile(paperPreferenceReq, acctPreferenceService.updateAccountsPreference);

        //Response
        //we should construct response here, (what ever we get from Middle Ware as response, we will convert it to our own response)
        //We will returning succsess or failure message
        //Success : Your account preferences updated successfully //200
        //Failed : Failed to update account preferences //500
        let respCode = 200;
        let respMsg = "Your account preferences updated successfully";
        res.send(`{"statusCode":${respCode},"message":${respMsg}}`);
    });

module.exports = router;