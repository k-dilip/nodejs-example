const bodyParser = require("body-parser");
const express = require("express");
let router = express.Router();

router.use(bodyParser.json());

router.route('/saveAndNotify')
    .post((req, res) => {
        console.log(req.body);
        let acctNum = req.body.acctNum;

        //Service => 
        //call save API
            //caller

        //get customer profile API
            //caller

        //call email notification API
            //caller

        let respCode = 200;
        let respMsg = "SUCCESS";
        res.send(`{"statusCode":${respCode},"message":${respMsg}}`);
    });


module.exports = router;